document.addEventListener('DOMContentLoaded', () => {
  // Atualiza o ano no elemento com data-year se presente
  const yearEl = document.querySelector('[data-year]');
  if (yearEl) {
    yearEl.textContent = String(new Date().getFullYear());
  }

  // Controle do menu móvel de navegação
  const navToggle = document.querySelector('.nav-toggle');
  const navLinks = document.querySelector('.nav-links');

  if (!navToggle || !navLinks) {
    return;
  }

  const openMenu = () => {
    navLinks.classList.add('is-open');
    navToggle.setAttribute('aria-expanded', 'true');
  };

  const closeMenu = (shouldFocusToggle = false) => {
    navLinks.classList.remove('is-open');
    navToggle.setAttribute('aria-expanded', 'false');
    if (shouldFocusToggle && document.activeElement !== navToggle) {
      navToggle.focus();
    }
  };

  const toggleMenu = () => {
    const isOpen = navLinks.classList.contains('is-open');
    if (isOpen) {
      closeMenu(false);
    } else {
      openMenu();
    }
  };

  navToggle.addEventListener('click', toggleMenu);

  // Suporte à tecla Escape para fechar o menu
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && navLinks.classList.contains('is-open')) {
      closeMenu(true);
    }
  });

  // Fecha o menu ao selecionar um link de navegação interna
  navLinks.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', () => {
      if (navLinks.classList.contains('is-open')) {
        closeMenu(false);
      }
    });
  });
});
